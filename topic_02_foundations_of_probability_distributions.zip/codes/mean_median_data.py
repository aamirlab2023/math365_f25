import random as random
import statistics as st

for i in range(20):
    print(random.randint(5000, 6500), end=", ")