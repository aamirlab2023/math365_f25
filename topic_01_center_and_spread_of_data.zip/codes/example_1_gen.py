import numpy as np

x = [5.44, 7.3, 6.03, 7.18, 7.95, 10.27, 13.12, 5.59, 8.10, 8.26]
x = np.array(x)

m = np.mean(x)
s = np.std(x)

print("<table>")
print("\t<tr>")
print("\t\t<th></th>")
print("\t\t<th></th>")
print("\t\t<th></th>")
print("\t\t<th></th>")
print("\t</tr>")
for value in x:
    print("\t<tr>")
    print(f"\t\t<td>\({value:.2f}\)</td>")
    print(f"\t\t<td>\({m:.2f}\)</td>")
    dev = value - m
    print(f"\t\t<td>\({value:.2f} - {m:.2f} = {dev:.2f}\)</td>")
    print(f"\t\t<td>\({dev:.2f}^2 = {dev**2:.2f}\)</td>")
    print("\t</tr>")

print("</table>")